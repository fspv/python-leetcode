# Problems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_name** | **str** |  | 
**num_solved** | **int** |  | 
**num_total** | **int** |  | 
**ac_easy** | **int** |  | 
**ac_medium** | **int** |  | 
**ac_hard** | **int** |  | 
**stat_status_pairs** | [**list[StatStatusPair]**](StatStatusPair.md) |  | 
**frequency_high** | **int** |  | 
**frequency_mid** | **int** |  | 
**category_slug** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

