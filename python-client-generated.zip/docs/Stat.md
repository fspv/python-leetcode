# Stat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**question_id** | **int** |  | 
**question__article__live** | **str** |  | [optional] 
**question__article__slug** | **str** |  | [optional] 
**question__article__has_video_solution** | **str** |  | [optional] 
**question__title** | **str** |  | 
**question__title_slug** | **str** |  | 
**question__hide** | **bool** |  | 
**total_acs** | **int** |  | 
**total_submitted** | **int** |  | 
**frontend_question_id** | **int** |  | 
**is_new_question** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

