# StatStatusPair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stat** | [**Stat**](Stat.md) |  | 
**status** | **str** |  | [optional] 
**difficulty** | [**Difficulty**](Difficulty.md) |  | 
**paid_only** | **bool** |  | 
**is_favor** | **bool** |  | 
**frequency** | **float** |  | 
**progress** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

