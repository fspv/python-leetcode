# Submission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**judge_type** | **str** |  | 
**lang** | **str** |  | 
**question_id** | **int** |  | 
**test_mode** | **bool** |  | 
**typed_code** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

