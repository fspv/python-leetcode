# SubmissionResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compare_result** | **str** |  | 
**std_output** | **str** |  | 
**last_testcase** | **str** |  | 
**expected_output** | **str** |  | 
**input_formatted** | **str** |  | 
**input** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

