# TestSubmissionResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code_answer** | **list[str]** |  | 
**correct_answer** | **bool** |  | [optional] 
**expected_status_code** | **int** |  | [optional] 
**expected_lang** | **str** |  | [optional] 
**expected_run_success** | **bool** |  | [optional] 
**expected_status_runtime** | **str** |  | [optional] 
**expected_memory** | **int** |  | [optional] 
**expected_code_answer** | **list[str]** |  | [optional] 
**expected_code_output** | **list[str]** |  | [optional] 
**expected_elapsed_time** | **int** |  | [optional] 
**expected_task_finish_time** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

